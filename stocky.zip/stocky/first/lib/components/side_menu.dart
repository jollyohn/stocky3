import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SideMenu extends StatefulWidget {
  const SideMenu({super.key});
  @override
  State<SideMenu> createState() => _SideMenuState();
}

class _SideMenuState extends State<SideMenu> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: ListView(
      padding: EdgeInsets.zero,
      children: [
        UserAccountsDrawerHeader(
            accountName: Text('WELCOME'),
            accountEmail: Text('IN STOCKY'),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white24,
              child: Icon(CupertinoIcons.person,
                  color: Color.fromARGB(255, 163, 143, 71)),
            ),
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 255, 255, 255),
              image: DecorationImage(
                image: NetworkImage(
                    '///C:/Users/jolly/Downloads/WhatsApp%20Image%202023-12-07%20at%2012.35.55_9f3303e6.svg'),
                fit: BoxFit.cover,
              ),
            )),
        ListTile(
          leading: Icon(Icons.favorite),
          title: Text('Favorites'),
          onTap: () => null,
        ),
        ListTile(
          leading: Icon(Icons.favorite),
          title: Text('Favorites'),
          onTap: () => null,
        ),
        ListTile(
          leading: Icon(Icons.people),
          title: Text('Favorites'),
          onTap: () => null,
        ),
        ListTile(
          leading: Icon(Icons.share),
          title: Text('Share'),
          onTap: () => null,
        ),
        ListTile(
            leading: Icon(Icons.shopping_bag),
            title: Text('Cart'),
            onTap: () => null,
            trailing: ClipOval(
              child: Container(
                  color: Colors.red,
                  width: 20,
                  height: 20,
                  child: Center(
                      child: Text('8',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          )))),
            )),
        Divider(),
        ListTile(
          leading: Icon(Icons.settings),
          title: Text('Settings'),
          onTap: () => null,
        ),
        ListTile(
          leading: Icon(Icons.help),
          title: Text('Help'),
          onTap: () => null,
        ),
        Divider(),
        ListTile(
          leading: Icon(Icons.login),
          title: Text('Login'),
          onTap: () => null,
        ),
        ListTile(
          leading: Icon(Icons.exit_to_app),
          title: Text('Logout'),
          onTap: () => null,
        )
      ],
    ));
  }
}
